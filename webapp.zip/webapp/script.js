        // Telegram Web App initialization
        let tg;
        try {
            tg = window.Telegram?.WebApp;
        } catch (error) {
            console.warn('Telegram WebApp not available, running in browser mode');
        }

        // Global variables
        let currentActivity = '';
        let formData = {};
        let photoFile = null;
        let totalSteps = 15;

        // Initialize app
        document.addEventListener('DOMContentLoaded', function() {
            initializeApp();
        });

        function initializeApp() {
            // Configure Telegram Web App if available
            if (tg) {
                tg.ready();
                tg.expand();
                
                // Set theme
                if (tg.backgroundColor) {
                    document.body.style.backgroundColor = tg.backgroundColor;
                }
            }
            
            // Hide loading screen with stagger animation
            setTimeout(() => {
                document.getElementById('loading').style.display = 'none';
                document.getElementById('app').style.display = 'block';
                document.getElementById('app').classList.add('fade-in');
            }, 1200);
            
            // Setup event listeners
            setupEventListeners();
            
            // Apply Telegram theme
            applyTelegramTheme();
        }

        function setupEventListeners() {
            // Form input listeners for real-time validation
            const form = document.getElementById('dataForm');
            const inputs = form.querySelectorAll('input, select');
            
            inputs.forEach(input => {
                input.addEventListener('blur', function() {
                    validateField(this);
                    updateProgress();
                });
                
                input.addEventListener('input', function() {
                    clearError(this);
                });
            });
            
            // Photo upload listener
            document.getElementById('foto_evidence').addEventListener('change', handlePhotoUpload);
            
            // Form submit listener
            form.addEventListener('submit', handleFormSubmit);
        }

        function selectActivity(activity) {
            currentActivity = activity;
            
            // Set kegiatan field
            const kegiatanSelect = document.getElementById('kegiatan');
            kegiatanSelect.value = activity;
            
            // Show/hide specific fields
            if (activity === 'Visit') {
                document.getElementById('visitFields').style.display = 'block';
                document.getElementById('dealingFields').style.display = 'none';
                // Make visit fields required
                document.getElementById('layanan').required = true;
                document.getElementById('tarif').required = true;
                // Remove dealing requirements
                document.getElementById('paket_deal').required = false;
                document.getElementById('deal_bundling').required = false;
            } else {
                document.getElementById('visitFields').style.display = 'none';
                document.getElementById('dealingFields').style.display = 'block';
                // Make dealing fields required
                document.getElementById('paket_deal').required = true;
                document.getElementById('deal_bundling').required = true;
                // Remove visit requirements
                document.getElementById('layanan').required = false;
                document.getElementById('tarif').required = false;
            }
            
            // Show form with enhanced animation
            document.getElementById('mainMenu').style.display = 'none';
            document.getElementById('formContainer').style.display = 'block';
            document.getElementById('formContainer').classList.add('slide-up');
            
            // Update form title
            document.getElementById('formTitle').textContent = `Form ${activity}`;
            
            // Update progress
            updateProgress();
            
            // Show Telegram back button if available
            if (tg?.BackButton) {
                tg.BackButton.show();
                tg.BackButton.onClick(backToMenu);
            }
            
            // Haptic feedback
            hapticFeedback('light');
        }

        function backToMenu() {
            // Reset form
            document.getElementById('dataForm').reset();
            clearAllErrors();
            removePhoto();
            
            // Show menu with fade animation
            document.getElementById('formContainer').style.display = 'none';
            document.getElementById('mainMenu').style.display = 'block';
            
            // Hide Telegram back button
            if (tg?.BackButton) {
                tg.BackButton.hide();
            }
            
            // Reset variables
            currentActivity = '';
            formData = {};
            photoFile = null;
            
            // Haptic feedback
            hapticFeedback('light');
        }

        function updateProgress() {
            const form = document.getElementById('dataForm');
            const requiredFields = form.querySelectorAll('[required]');
            let filledFields = 0;
            
            requiredFields.forEach(field => {
                if (field.type === 'file') {
                    if (photoFile) filledFields++;
                } else if (field.value.trim() !== '') {
                    filledFields++;
                }
            });
            
            const progress = (filledFields / requiredFields.length) * 100;
            document.getElementById('progressFill').style.width = `${progress}%`;
            document.getElementById('currentStep').textContent = filledFields;
            document.getElementById('totalSteps').textContent = requiredFields.length;
        }

        function validateField(field) {
            const fieldName = field.name;
            const value = field.value.trim();
            let isValid = true;
            let errorMessage = '';
            
            // Basic required validation
            if (field.required && !value) {
                isValid = false;
                errorMessage = 'Field ini wajib diisi';
            } else {
                // Specific field validations
                switch (fieldName) {
                    case 'kode_sa':
                        if (!/^[A-Za-z0-9]{3,10}$/.test(value)) {
                            isValid = false;
                            errorMessage = 'Kode SA harus 3-10 karakter alfanumerik';
                        }
                        break;
                        
                    case 'nama':
                    case 'nama_pic':
                    case 'jabatan_pic':
                        if (value.length < 2) {
                            isValid = false;
                            errorMessage = 'Minimal 2 karakter';
                        }
                        break;
                        
                    case 'no_telp':
                    case 'telepon_pic':
                        if (!/^(\+62|62|0)[0-9]{9,13}$/.test(value.replace(/\s+/g, ''))) {
                            isValid = false;
                            errorMessage = 'Format nomor HP tidak valid';
                        }
                        break;
                        
                    case 'telda':
                    case 'tenant':
                        if (value.length < 3) {
                            isValid = false;
                            errorMessage = 'Minimal 3 karakter';
                        }
                        break;
                        
                    case 'tanggal':
                        const selectedDate = new Date(value);
                        const today = new Date();
                        const oneYearAgo = new Date();
                        oneYearAgo.setFullYear(today.getFullYear() - 1);
                        
                        if (selectedDate > today) {
                            isValid = false;
                            errorMessage = 'Tanggal tidak boleh di masa depan';
                        } else if (selectedDate < oneYearAgo) {
                            isValid = false;
                            errorMessage = 'Tanggal tidak boleh lebih dari 1 tahun lalu';
                        }
                        break;
                }
            }
            
            // Update field appearance and error message
            const errorElement = document.getElementById(`error_${fieldName}`);
            if (isValid) {
                field.classList.remove('error');
                field.classList.add('valid');
                if (errorElement) errorElement.classList.remove('show');
            } else {
                field.classList.remove('valid');
                field.classList.add('error');
                if (errorElement) {
                    errorElement.textContent = errorMessage;
                    errorElement.classList.add('show');
                }
            }
            
            return isValid;
        }

        function clearError(field) {
            const errorElement = document.getElementById(`error_${field.name}`);
            field.classList.remove('error');
            if (errorElement) {
                errorElement.classList.remove('show');
            }
        }

        function clearAllErrors() {
            const errorElements = document.querySelectorAll('.error-message');
            errorElements.forEach(el => el.classList.remove('show'));
            
            const fields = document.querySelectorAll('.form-group input, .form-group select');
            fields.forEach(field => {
                field.classList.remove('error', 'valid');
            });
        }

        function handlePhotoUpload(event) {
            const file = event.target.files[0];
            if (!file) return;
            
            // Validate file
            const maxSize = 5 * 1024 * 1024; // 5MB
            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
            
            if (file.size > maxSize) {
                showError('foto_evidence', 'Ukuran file maksimal 5MB');
                event.target.value = '';
                return;
            }
            
            if (!allowedTypes.includes(file.type)) {
                showError('foto_evidence', 'Format file harus JPG atau PNG');
                event.target.value = '';
                return;
            }
            
            // Show preview with animation
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('previewImg').src = e.target.result;
                document.getElementById('photoPreview').style.display = 'block';
                document.getElementById('uploadPrompt').style.display = 'none';
                photoFile = e.target.result;
                clearError(event.target);
                updateProgress();
                
                // Haptic feedback for successful upload
                hapticFeedback('medium');
            };
            reader.readAsDataURL(file);
        }

        function removePhoto(event) {
            if (event) event.stopPropagation();
            
            document.getElementById('foto_evidence').value = '';
            document.getElementById('photoPreview').style.display = 'none';
            document.getElementById('uploadPrompt').style.display = 'block';
            photoFile = null;
            updateProgress();
            
            // Haptic feedback
            hapticFeedback('light');
        }

        function showError(fieldName, message) {
            const field = document.getElementById(fieldName);
            const errorElement = document.getElementById(`error_${fieldName}`);
            
            if (field) field.classList.add('error');
            if (errorElement) {
                errorElement.textContent = message;
                errorElement.classList.add('show');
            }
        }

        function validateAllFields() {
            const form = document.getElementById('dataForm');
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (field.type === 'file') {
                    if (!photoFile) {
                        showError('foto_evidence', 'Foto evidence wajib diupload');
                        isValid = false;
                    }
                } else if (!validateField(field)) {
                    isValid = false;
                }
            });
            
            return isValid;
        }

        function collectFormData() {
            const form = document.getElementById('dataForm');
            const formData = new FormData(form);
            const data = {};
            
            // Collect all form fields
            for (let [key, value] of formData.entries()) {
                if (key !== 'foto_evidence') {
                    data[key] = value.trim();
                }
            }
            
            // Add photo as base64
            if (photoFile) {
                data.foto_evidence = photoFile;
            }
            
            // Set activity-specific defaults
            if (currentActivity === 'Visit') {
                data.paket_deal = '-';
                data.deal_bundling = '-';
            } else if (currentActivity === 'Dealing') {
                data.layanan = '-';
                data.tarif = '-';
            }
            
            // Format date
            if (data.tanggal) {
                const date = new Date(data.tanggal);
                data.tanggal = date.toLocaleDateString('id-ID', {
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric'
                });
            }
            
            return data;
        }

        async function handleFormSubmit(event) {
            event.preventDefault();
            
            // Validate all fields
            if (!validateAllFields()) {
                // Scroll to first error with smooth animation
                const firstError = document.querySelector('.error');
                if (firstError) {
                    firstError.scrollIntoView({ 
                        behavior: 'smooth', 
                        block: 'center' 
                    });
                }
                
                // Haptic feedback for error
                hapticFeedback('heavy');
                return;
            }
            
            // Show loading state with enhanced animation
            const submitButton = document.getElementById('submitButton');
            const buttonText = submitButton.querySelector('.button-text');
            const buttonLoader = submitButton.querySelector('.button-loader');
            
            submitButton.disabled = true;
            buttonText.style.display = 'none';
            buttonLoader.style.display = 'block';
            
            try {
                // Collect form data
                const data = collectFormData();
                
                // Send data to Telegram bot if available
                if (tg && tg.sendData) {
                    tg.sendData(JSON.stringify(data));
                } else {
                    // Fallback for browser testing
                    console.log('Form data:', data);
                    alert('Demo mode: Data would be sent to Telegram bot');
                }
                
                // Show success message
                showMessage('success', 'Data Berhasil Dikirim!', 
                    `Data ${currentActivity} telah dikirim ke bot untuk diproses. Tunggu konfirmasi dari bot.`);
                
                // Success haptic feedback
                hapticFeedback('heavy');
                
            } catch (error) {
                console.error('Error submitting form:', error);
                showMessage('error', 'Gagal Mengirim Data', 
                    'Terjadi kesalahan saat mengirim data. Silakan coba lagi.');
                
                // Error haptic feedback
                hapticFeedback('heavy');
            } finally {
                // Reset button state
                submitButton.disabled = false;
                buttonText.style.display = 'block';
                buttonLoader.style.display = 'none';
            }
        }

        function showMessage(type, title, message) {
            const container = document.getElementById('messageContainer');
            const icon = document.getElementById('messageIcon');
            const titleEl = document.getElementById('messageTitle');
            const textEl = document.getElementById('messageText');
            
            if (type === 'success') {
                icon.textContent = '✅';
                icon.style.color = '#00e676';
            } else {
                icon.textContent = '❌';
                icon.style.color = '#ff6b6b';
            }
            
            titleEl.textContent = title;
            textEl.textContent = message;
            container.style.display = 'flex';
            container.classList.add('fade-in');
        }

        function hideMessage() {
            document.getElementById('messageContainer').style.display = 'none';
        }

        // Theme handling
        function applyTelegramTheme() {
            if (tg?.colorScheme === 'dark') {
                document.body.classList.add('dark-theme');
            }
            
            // Apply Telegram theme colors if available
            if (tg?.themeParams) {
                const root = document.documentElement;
                root.style.setProperty('--tg-bg-color', tg.themeParams.bg_color || '#ffffff');
                root.style.setProperty('--tg-text-color', tg.themeParams.text_color || '#000000');
                root.style.setProperty('--tg-hint-color', tg.themeParams.hint_color || '#7f8c8d');
                root.style.setProperty('--tg-button-color', tg.themeParams.button_color || '#667eea');
            }
        }

        // Haptic feedback for better UX
        function hapticFeedback(type = 'light') {
            if (tg?.HapticFeedback) {
                try {
                    tg.HapticFeedback.impactOccurred(type);
                } catch (error) {
                    console.warn('Haptic feedback not supported');
                }
            }
        }

        // Handle theme changes
        if (tg) {
            tg.onEvent('themeChanged', applyTelegramTheme);
            
            // Handle main button (if needed)
            if (tg.MainButton) {
                tg.MainButton.setText('Submit Data');
                tg.MainButton.onClick(function() {
                    const form = document.getElementById('dataForm');
                    if (form.style.display !== 'none') {
                        form.dispatchEvent(new Event('submit'));
                    }
                });
            }
        }

        console.log('🚀 RLEGS Mini App Enhanced - Ready!');
